#ifndef __crc1w_h__
#define __crc1w_h__

#include <sys/types.h>

typedef u_int8_t uint8_t;
extern uint8_t crc1w(int, uint8_t*);


#endif

