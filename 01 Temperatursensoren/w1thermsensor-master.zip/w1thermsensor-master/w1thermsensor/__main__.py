# -*- coding: utf-8 -*-

"""
    Main module to launch w1thermsensor CLI.
"""

from .cli import cli

if __name__ == "__main__":
    cli()
